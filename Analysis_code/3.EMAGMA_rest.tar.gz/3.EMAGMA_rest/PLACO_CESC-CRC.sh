zcat /home/yanyq/share_genetics/result/PLACO/PLACO_CESC-CRC.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-CRC
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-CRC
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-CRC N=602529 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_CESC-CRC
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-CRC
