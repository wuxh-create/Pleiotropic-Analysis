zcat /home/yanyq/share_genetics/result/PLACO/PLACO_LIHC-SKCM.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_LIHC-SKCM
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_LIHC-SKCM
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_LIHC-SKCM N=632080 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_LIHC-SKCM
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_LIHC-SKCM
