zcat /home/yanyq/share_genetics/result/PLACO/PLACO_TEST-PRAD.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_TEST-PRAD
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_TEST-PRAD
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_TEST-PRAD N=858520 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_TEST-PRAD
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_TEST-PRAD
