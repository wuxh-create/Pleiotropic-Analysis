zcat /home/yanyq/share_genetics/result/PLACO/PLACO_BCC-MM.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MM
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MM
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MM N=649507 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_BCC-MM
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MM
