zcat /home/yanyq/share_genetics/result/PLACO/PLACO_GSS-HNSC.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_GSS-HNSC
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_GSS-HNSC
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_GSS-HNSC N=630879 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_GSS-HNSC
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_GSS-HNSC
