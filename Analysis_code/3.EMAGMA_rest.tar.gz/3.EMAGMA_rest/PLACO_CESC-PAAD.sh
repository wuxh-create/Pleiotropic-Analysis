zcat /home/yanyq/share_genetics/result/PLACO/PLACO_CESC-PAAD.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-PAAD
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-PAAD
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-PAAD N=732732 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_CESC-PAAD
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_CESC-PAAD
