zcat /home/yanyq/share_genetics/result/PLACO/PLACO_BCC-MS.gz | cut -f 1,6  > /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MS
sed -i '1d' /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MS
while read tissue
do
magma --bfile ~/share_genetics/data/MAGMA/g1000_eur/g1000_eur --gene-annot /home/yanyq/software/eMAGMA-tutorial/$tissue.genes.annot --pval /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MS N=649001 --out ~/share_genetics/result/EMAGMA/asso/$tissue/PLACO_BCC-MS
done < /home/yanyq/software/eMAGMA-tutorial/annot_file
rm /home/yanyq/share_genetics/result/PLACO/tmp_PLACO_BCC-MS
