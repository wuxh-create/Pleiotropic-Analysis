# 开始计算
    library(readr)
    library(LDlinkR)
    j = 107
    cal_pair = as.data.frame(read_tsv(paste0("/home/yanyq/share_genetics/result/GWAS_catalog/LDpair_error_2/", j)))
    results = list()
    errors = list()
    for(i in 1:nrow(cal_pair)){
      result <- tryCatch({
        LDpair(var1 = cal_pair$snp1[i], var2 = cal_pair$snp2[i], pop = "EUR", token = "0eaa42cc5d9f")
      }, error = function(e) {
        # 打印错误信息并保留错误的SNP对
        message(paste("Error in LDpair for SNPs", cal_pair$snp1[i], "and", cal_pair$snp2[i], ":", e$message))
        errors <<- c(errors, list(list(snp1 = cal_pair$snp1[i], snp2 = cal_pair$snp2[i], error = e$message)))
        return(NULL)
      })
      if (!is.null(result)) {
        results <- c(results, list(result))
      }
    }
    
    write_rds(results, paste0("/home/yanyq/share_genetics/result/GWAS_catalog/LDpair_error_2_res/",j,".rds"))
    write_rds(errors, paste0("/home/yanyq/share_genetics/result/GWAS_catalog/LDpair_error_2_res/",j,"_errors.rds"))
