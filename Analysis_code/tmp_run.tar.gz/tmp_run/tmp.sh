for i in {1..126}
do
	echo 'nohup Rscript '$i'.R >& '$i'.log &'
done
